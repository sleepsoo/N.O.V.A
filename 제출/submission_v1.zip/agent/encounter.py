"""진료 흐름: 시작 정보 구조화 → 공감 → 문진(규칙+적응형) → 진찰 → 진단 투표 → 계획 → 설명 → 기록 제출."""
from __future__ import annotations

import json
import re
import time
import uuid

from nova_sdk import NovaError

from . import banks
from .llm import Budget, ask, ask_json
from .util import (MAX_CHARS, clen, fits, is_one_at_a_time, is_similar, log, log_error, nfc, parse_age, parse_sex,
                   split_to_fit, validate_question)

STOP_CODES = {'TURN_LIMIT_REACHED', 'SESSION_EXPIRED', 'SESSION_CLOSED', 'RUN_NOT_ACTIVE'}
TURN_USING = {'EMPTY_CONTENT', 'CONTENT_TOO_LONG', 'EXAM_NOT_SPECIFIC', 'EXAM_NOT_RECOGNIZED'}
ACTION_SAME_ID = {'API_UNAVAILABLE', 'REQUEST_PENDING', 'LOCAL_GATEWAY_UNAVAILABLE', 'INVALID_API_RESPONSE', 'API_ERROR'}
ACTION_NEW_ID = {'PATIENT_RESPONSE_INVALID', 'EXAMINER_RESPONSE_INVALID'}

DOCTOR_ROLE = '당신은 한국 외래 진료실의 숙련된 의사입니다. 가상 환자를 진료하고 있습니다.'
EXPLAIN_KEYS = ('diagnosis', 'tests', 'treatment', 'warning', 'lifestyle', 'concern')


class Encounter:
    def __init__(self, client, cfg: dict):
        self.client = client
        self.cfg = cfg
        session = client.session()
        self.session = session
        initial = session.get('initial') or {}
        self.opening = nfc(initial.get('opening') or '')
        self.vitals = nfc(initial.get('vital_signs') or '')
        self.budget = Budget(session.get('deadline'))
        self.turns_remaining = int(session.get('turns_remaining') or 50)
        self.turn = max(0, 50 - self.turns_remaining)
        self.ledger: list[dict] = []
        self.asked: list[str] = []
        self.planned: list[str] = []
        self.counts = {'say': 0, 'exam': 0, 'refused': 0, 'one_at_a_time': 0, 'skipped_invalid': 0,
                       'exam_refused': 0, 'interview': 0}
        self.stopped = False
        self.profile: dict = {}
        self.differentials: list[str] = []
        self.dx = ''
        self.dx_detail: dict = {}
        self.plan: dict = {}
        self.explained: list[str] = []
        self.blacklist: set[str] = set()
        self.done_exams: list[str] = []
        self.ros_priority: list[str] = []

    # ------------------------------------------------------------------ actions
    def time_left(self) -> float:
        return self.budget.seconds_left()

    def can_act(self) -> bool:
        return not self.stopped and self.turns_remaining > 0 and self.time_left() > 90

    def act(self, kind: str, text: str, *, phase: str, qid: str = '', label: str = ''):
        """SAY/EXAM 한 번. 성공하면 원장 항목, 거절이면 {'refused': code}, 실행 못 하면 None."""
        if not self.can_act():
            return None
        text = nfc(text).strip()
        if not fits(text, MAX_CHARS):
            self.counts['skipped_invalid'] += 1
            log(f'skip invalid text ({clen(text)}): {text!r}')
            return None
        request_id = str(uuid.uuid4())
        reply = None
        for attempt in range(7):
            try:
                if kind == 'SAY':
                    reply = self.client.say(text, request_id=request_id)
                else:
                    reply = self.client.exam(text, request_id=request_id)
                break
            except NovaError as exc:
                code = exc.code
                if code in STOP_CODES:
                    self.stopped = True
                    log_error(f'{kind} stop {code}')
                    return None
                if code in TURN_USING:
                    self.turn += 1
                    self.turns_remaining -= 1
                    self.counts['refused'] += 1
                    if kind == 'EXAM':
                        self.counts['exam_refused'] += 1
                    self.ledger.append({'turn': self.turn, 'kind': kind, 'text': text, 'reply': '', 'phase': phase,
                                        'refused': code, 'qid': qid, 'label': label})
                    log(f'turn {self.turn} {kind} REFUSED {code}: {text}')
                    return {'refused': code}
                if code in ACTION_SAME_ID:
                    time.sleep(min(3 * (attempt + 1), 15))
                    continue
                if code in ACTION_NEW_ID:
                    request_id = str(uuid.uuid4())
                    time.sleep(2)
                    continue
                log_error(f'{kind} unexpected {code}: {text}')
                return None
            except ValueError as exc:  # SDK 길이 검사
                log_error(f'{kind} ValueError {exc}')
                return None
        if reply is None:
            log_error(f'{kind} gave up after retries: {text}')
            return None
        turn = reply.get('turn')
        self.turn = int(turn) if isinstance(turn, int) else self.turn + 1
        tr = reply.get('turns_remaining')
        self.turns_remaining = int(tr) if isinstance(tr, int) else self.turns_remaining - 1
        answer = nfc(reply.get('content') if kind == 'SAY' else reply.get('result') or '').strip()
        entry = {'turn': self.turn, 'kind': kind, 'text': text, 'reply': answer, 'phase': phase, 'qid': qid,
                 'label': label}
        self.ledger.append(entry)
        if kind == 'SAY':
            self.counts['say'] += 1
            self.asked.append(text)
            if is_one_at_a_time(answer):
                self.counts['one_at_a_time'] += 1
                entry['one_at_a_time'] = True
        else:
            self.counts['exam'] += 1
        log(f'turn {self.turn} {kind}: {text} -> {answer[:60]}')
        return entry

    # ------------------------------------------------------------------ transcript helpers
    def start_info(self) -> str:
        return f'시작 정보(환자 첫 진술, 확인된 사실): {self.opening}\n시작 활력징후: {self.vitals.replace(chr(10), ", ")}'

    def transcript(self, *, include_refused=False, clinical_only=False) -> str:
        """clinical_only: 공감·마무리 설명 턴 제외(근거·계획 작성용)."""
        lines = []
        for e in self.ledger:
            if clinical_only and e.get('phase') in ('empathy', 'explain', 'explain-answer'):
                continue
            if e.get('refused'):
                if include_refused:
                    lines.append(f"턴 {e['turn']} | ({e['kind']} 거절: {e['text']})")
                continue
            if e['kind'] == 'SAY':
                lines.append(f"턴 {e['turn']} | 의사: {e['text']} | 환자: {e['reply']}")
            else:
                lines.append(f"턴 {e['turn']} | 진찰({exam_name(e['text'])}): {e['reply']}")
        return '\n'.join(lines) or '(아직 없음)'

    def interview_left(self) -> int:
        # 진찰·설명 턴을 남겨 두도록 서버 잔여 턴으로도 제한
        by_turns = self.turns_remaining - (self.cfg['EXAM_MAX'] + self.cfg['EXPLAIN_MAX'] + 2)
        return min(self.cfg['INTERVIEW_MAX'] - self.counts['interview'], by_turns)

    def phase_time_ok(self) -> bool:
        return self.time_left() > self.cfg['WRAPUP_SECONDS']

    # ------------------------------------------------------------------ 1. 시작 정보 구조화
    def structure(self):
        age = parse_age(self.opening)
        sex = parse_sex(self.opening)
        peds_re = bool(re.search(r'(보호자|엄마|아빠|어머니|아버지).{0,20}(함께|같이|데리고|동반)', self.opening))
        cats_list = list(banks.CATEGORY_BUNDLES)
        hpi = banks.PEDS_HPI if (age is not None and age < 15) else banks.ADULT_HPI
        sys_prompt = DOCTOR_ROLE + ' 진료 시작 전 환자 첫 진술을 정리합니다. JSON 객체 하나만 출력하세요.'
        user = (f'{self.start_info()}\n\n'
                '다음 키를 가진 JSON을 출력하세요.\n'
                '{"age": 나이(정수, 모르면 null), "sex": "M" 또는 "F", "pediatric": 소아 환자이고 보호자가 대신 답하면 true,\n'
                ' "chief_complaint": "주호소(짧은 한국어 명사구)", "pain": 통증이 주호소면 true,\n'
                f' "categories": {cats_list} 중 주호소와 관련된 것 1~3개,\n'
                f' "answered": 첫 진술에 이미 답이 있는 문진 항목 id 목록 (가능한 id: {[h[0] for h in hpi]}),\n'
                ' "empathy": "주호소로 겪은 불편·걱정을 알아주는 공감 한마디(존댓말, 25자 이내, 질문 아님. '
                '예시 - 살이 갑자기 빠져서 많이 걱정되셨겠어요. / 잠을 못 주무셔서 많이 힘드셨겠어요.)"}')
        res = ask_json(self.client, self.budget, sys_prompt, user, effort='low', max_tokens=1500, tag='structure',
                       want=dict, tries=2)
        res = res if isinstance(res, dict) else {}
        try:
            llm_age = int(res.get('age')) if res.get('age') is not None else None
        except (TypeError, ValueError):
            llm_age = None
        if age is None:
            age = llm_age
        if not sex and str(res.get('sex', '')).upper() in ('M', 'F'):
            sex = str(res['sex']).upper()
        pediatric = (age is not None and age < 15) or (peds_re and (age is None or age < 18))
        cc = nfc(res.get('chief_complaint') or '').strip()
        if not cc:
            cc = self.opening.split('.')[1].strip() if '.' in self.opening else self.opening[:40]
        # LLM 카테고리는 키워드로도 확인될 때만 채택(불면에 neuro가 붙는 식의 잡음 방지)
        cats = [c for c in (res.get('categories') or []) if c in banks.CATEGORY_BUNDLES
                and re.search(banks.CATEGORY_BUNDLES[c][0], cc + ' ' + self.opening)]
        for c in banks.detect_categories(cc + ' ' + self.opening, pediatric):
            if c not in cats and len(cats) < 4:
                cats.append(c)
        # 소아가 아니면 growth 묶음은 의미 없음
        cats = [c for c in cats if banks.bundle_questions([c], pediatric)]
        if res.get('pain') and 'pain' not in cats and not pediatric:
            cats.insert(0, 'pain')
        if pediatric and 'growth' in cats:
            cats = ['growth']  # 소아 성장 문제는 성장 묶음만(부모 키·사춘기 시기 등 핵심 문항 우선)
        # 약물 관련 주호소(처방 요구 등)는 약물 묶음(복용량·내성·금단·여러 곳 처방)이 진단의 핵심이므로 맨 앞
        for first in ('growth', 'drug'):
            if first in cats:
                cats.remove(first)
                cats.insert(0, first)
        answered = [a for a in (res.get('answered') or []) if isinstance(a, str)]
        empathy = nfc(res.get('empathy') or '').strip()
        if not fits(empathy, MAX_CHARS) or '?' in empathy:
            empathy = '많이 걱정되셨겠어요.'
        self.profile = {'age': age, 'sex': sex, 'pediatric': bool(pediatric), 'cc': cc, 'categories': cats[:3],
                        'answered': answered, 'empathy': empathy}
        log(f'profile: {self.profile}')

    # ------------------------------------------------------------------ 2. 문진
    def ask_question(self, q: str, *, phase: str, qid: str = '', label: str = '', check_dup=True) -> bool:
        if self.interview_left() <= 0 or not self.can_act():
            return False
        if check_dup and is_similar(q, self.asked):
            return False
        entry = self.act('SAY', q, phase=phase, qid=qid, label=label)
        if entry is None:
            return False
        self.counts['interview'] += 1
        if isinstance(entry, dict) and entry.get('one_at_a_time'):
            self.retry_single(q, phase)
        return True

    def retry_single(self, q: str, phase: str):
        """'한 번에 하나씩' 응답: 질문을 하나로 줄여 한 번만 다시 묻는다."""
        simple = None
        m = re.match(r'^(.*?)(?:이나|나|랑|이랑|와|과|,)\s', q)
        if m:
            tail = re.search(r'(있으세요\?|있나요\?|하세요\?|드세요\?|나요\?|세요\?)$', q)
            if tail:
                cand = f'{m.group(1)} {tail.group(1)}'
                if fits(cand) and not is_similar(cand, self.asked, 0.9):
                    simple = cand
        if simple is None:
            res = ask(self.client, self.budget, DOCTOR_ROLE,
                      f'환자가 "한 번에 하나씩 물어봐 주세요"라고 했습니다. 다음 질문을 한 가지만 묻는 25자 이내 질문으로 바꾸세요: "{q}"\n'
                      'JSON {"question": "..."} 하나만 출력.', effort='low', max_tokens=800, tag='single', want=dict,
                      reserve=self.cfg['CALL_RESERVE'])
            cand = nfc((res or {}).get('question') or '').strip()
            ok, _ = validate_question(cand, None)
            if ok:
                simple = cand
        if simple and self.interview_left() > 0:
            entry = self.act('SAY', simple, phase=phase + '-single')
            if entry and not entry.get('refused'):
                self.counts['interview'] += 1

    def ask_bank(self, items, *, phase: str, cap: int, skip_text: str = ''):
        n = 0
        for item in items:
            if n >= cap or self.interview_left() <= 0 or not self.phase_time_ok():
                break
            qid, q, label = item[0], item[1], item[2]
            skip = item[3] if len(item) > 3 else None
            if qid in ('aggravate', 'relieve') and not (set(self.profile.get('categories') or []) & banks.SYMPTOM_CATS):
                continue
            if skip and re.search(skip, skip_text or self.opening):
                continue
            if self.ask_question(q, phase=phase, qid=qid, label=label):
                n += 1
        return n

    def adaptive(self, n_questions: int, round_no: int, ros_menu=None):
        if n_questions <= 0 or self.interview_left() <= 0 or not self.phase_time_ok():
            return
        upcoming = [q for q in self.planned if not is_similar(q, self.asked, 0.9)]
        sys_prompt = (DOCTOR_ROLE + ' 감별진단을 좁히기 위한 다음 문진 질문을 고릅니다. JSON 객체 하나만 출력하세요.')
        ros_part, ros_out = '', ''
        if ros_menu:
            ros_part = '\n일반 계통 문진 목록 (id | 질문):\n' + '\n'.join(f'{r[0]} | {r[1]}' for r in ros_menu) + '\n'
            ros_out = ', "ros_ids": ["위 계통 문진 목록 중 이 환자에게 중요한 순서대로 id 4~6개"]'
        user = (f'{self.start_info()}\n\n지금까지의 진료:\n{self.transcript()}\n\n'
                f'이후 따로 물을 예정인 질문(이것과 같은 내용은 절대 내지 말 것): {upcoming}\n{ros_part}\n'
                '방법: 먼저 가능성 높은 감별진단 3~5개를 정하고, 각 감별진단을 지지하거나 배제하는 특징 증상·징후·위험인자 중 '
                '아직 확인하지 않은 것을 질문으로 만드세요. (예: 흉통이면 운동 시 악화, 왼팔로 퍼짐, 식은땀, 흡연 등)\n'
                '규칙: 한국어 존댓말, 한 번에 한 가지 증상만, 25자 이내, 물음표 하나, 예/아니요로 답할 수 있게. '
                '"전부/모두/다/요약" 금지. 환자에게 진단명을 묻지 말 것. 이미 물었거나 환자가 이미 말한 내용·예정된 질문은 제외.\n'
                f'출력: {{"differentials": ["가능성 높은 순 감별진단"], "questions": ["중요한 순서로 질문 {n_questions + 4}개"]{ros_out}}}')
        res = ask_json(self.client, self.budget, sys_prompt, user, effort='medium', max_tokens=4000,
                       tag=f'adaptive{round_no}', want=dict, tries=2, reserve=self.cfg['CALL_RESERVE'])
        if not isinstance(res, dict):
            return
        diffs = [nfc(d).strip() for d in (res.get('differentials') or []) if isinstance(d, str) and d.strip()]
        if diffs:
            self.differentials = diffs[:5]
        if ros_menu:
            ids = [str(i) for i in (res.get('ros_ids') or []) if isinstance(i, (str, int))]
            self.ros_priority = [i for i in ids if any(r[0] == i for r in ros_menu)]
        qs = [nfc(q).strip() for q in (res.get('questions') or []) if isinstance(q, str)]
        good, bad = [], []
        for q in qs:
            if is_similar(q, upcoming):
                continue
            ok, why = validate_question(q, self.asked + good)
            if ok:
                good.append(q)
            elif why in ('too_long', 'multi', 'list', 'multi_q'):
                bad.append(q)
        if bad and len(good) < n_questions:
            fix = ask_json(self.client, self.budget, DOCTOR_ROLE,
                           '다음 질문들을 각각 한 가지만 묻는 25자 이내 존댓말 질문으로 줄이세요. '
                           f'JSON {{"questions": [...]}} 하나만 출력.\n{bad}', effort='low', max_tokens=1500,
                           tag='shorten', want=dict, tries=1, reserve=self.cfg['CALL_RESERVE'])
            for q in (fix or {}).get('questions') or []:
                q = nfc(q).strip()
                ok, _ = validate_question(q, self.asked + good)
                if ok:
                    good.append(q)
        log(f'adaptive{round_no}: diffs={self.differentials} good={good}')
        n = 0
        for q in good:
            if n >= n_questions:
                break
            if self.ask_question(q, phase=f'adaptive{round_no}', qid=f'ad{round_no}', label='적응형'):
                n += 1

    def interview(self):
        cfg, prof = self.cfg, self.profile
        peds = prof['pediatric']
        # 공감
        if self.can_act():
            self.act('SAY', prof['empathy'], phase='empathy')
        hpi = banks.PEDS_HPI if peds else banks.ADULT_HPI
        history = list(banks.PEDS_HISTORY if peds else banks.ADULT_HISTORY)
        if not peds and prof.get('sex') == 'F' and prof.get('age') and 12 <= prof['age'] <= 55:
            idx = next((i for i, h in enumerate(history) if h[0] == 'fh_similar'), len(history))
            history[idx:idx] = [(w[0], w[1], w[2]) for w in banks.WOMEN_BUNDLE if w[0] in ('wm_change', 'wm_preg')]
        bundle = banks.bundle_questions(prof['categories'], peds)
        ros = banks.PEDS_ROS if peds else banks.ADULT_ROS
        ice = banks.PEDS_ICE if peds else banks.ADULT_ICE
        self.planned = [h[1] for h in history] + [i[1] for i in ice] + [r[1] for r in ros[:9]]
        self.ask_bank(hpi, phase='hpi', cap=cfg['HPI_MAX'])
        self.ask_bank(bundle, phase='bundle', cap=cfg['BUNDLE_MAX'])
        self.adaptive(cfg['ADAPTIVE1_MAX'], 1)
        ad2_min = min(2, cfg['ADAPTIVE2_MAX'])
        hist_cap = max(0, self.interview_left() - (len(ice) + cfg['ROS_MIN'] + ad2_min))
        self.ask_bank(history, phase='history', cap=hist_cap)
        # ROS는 은행의 핵심 순서(두근거림·숨참·흉통·수면·기분·배변·배뇨·부종·피로)를 그대로 쓴다.
        # (LLM 우선순위는 실험에서 핵심 항목을 뒤로 미루는 경향이 있어 사용하지 않음)
        ros_cap = max(0, self.interview_left() - len(ice) - ad2_min)
        self.ask_bank(ros, phase='ros', cap=min(ros_cap, cfg['ROS_MAX']), skip_text=prof['cc'] + ' ' + self.opening)
        self.planned = [i[1] for i in ice]
        self.adaptive(min(cfg['ADAPTIVE2_MAX'], max(0, self.interview_left() - len(ice))), 2)
        self.ask_bank(ice, phase='ice', cap=len(ice))

    # ------------------------------------------------------------------ 3. 진찰
    def choose_exams(self) -> list[str]:
        prof = self.profile
        n = self.cfg['EXAM_SELECT']
        diff_txt = ' '.join(self.differentials)
        allowed = [e for e in banks.EXAM_BANK if e[0] not in banks.ALWAYS_EXAMS
                   and (e[0] not in banks.CONDITIONAL_EXAMS or re.search(banks.CONDITIONAL_EXAMS[e[0]], diff_txt))]
        allowed_ids = {e[0] for e in allowed}
        menu = '\n'.join(f'{e[0]} | {exam_name(e[1])} | {e[4]}' for e in allowed)
        sys_prompt = DOCTOR_ROLE + ' 신체진찰 항목을 고릅니다. JSON 객체 하나만 출력하세요.'
        user = (f'{self.start_info()}\n\n문진 내용:\n{self.transcript()}\n\n현재 감별진단: {self.differentials}\n\n'
                f'진찰 목록 (id | 진찰 | 관련 키워드):\n{menu}\n\n'
                f'활력징후·전반적 외관·심음 청진·폐 청진은 이미 하기로 했습니다. 감별진단을 확인·배제하는 데 가장 중요한 진찰 {n}개를 '
                '중요한 순서로 목록의 id로만 고르세요. 같은 부위의 비슷한 진찰을 중복해 고르지 마세요.\n'
                '출력: {"exam_ids": ["id", ...]}')
        res = ask_json(self.client, self.budget, sys_prompt, user, effort='medium', max_tokens=3000, tag='exams',
                       want=dict, tries=2, reserve=self.cfg['CALL_RESERVE'])
        llm_ids = []
        for i in (res or {}).get('exam_ids') or []:
            i = str(i).strip()
            if i in allowed_ids and i not in llm_ids:
                llm_ids.append(i)
        # 카테고리 핵심 진찰
        cat_ids = []
        cats = list(prof.get('categories') or [])
        if re.search(banks.THYROID_RE, diff_txt, flags=re.I):
            cats.insert(0, 'thyroid')
        if prof.get('pediatric') and 'growth' in cats:
            cats.remove('growth')
            cats.insert(0, 'growth')
        for c in cats:
            cat_ids += [i for i in banks.CATEGORY_EXAMS.get(c, [])[:5] if i not in cat_ids]
        # 합치기: LLM 상위 4개 → 카테고리 핵심 → 나머지 LLM → 기본 진찰
        ids = []
        k = 1 if (prof.get('pediatric') and 'growth' in cats) else 2
        for i in llm_ids[:k] + cat_ids + llm_ids[k:] + banks.CATEGORY_EXAMS['default']:
            if i not in ids and i in allowed_ids:
                ids.append(i)
        # 중복 그룹 제거
        out, groups = [], set()
        for i in ids:
            g = banks.EXAM_BY_ID[i][3]
            if g in groups:
                continue
            groups.add(g)
            out.append(i)
        return out[:n]

    def examine(self):
        if not self.can_act():
            return
        chosen = banks.ALWAYS_EXAMS + self.choose_exams()
        log(f'exams: {chosen}')
        budget_turns = min(self.cfg['EXAM_MAX'], self.turns_remaining - (self.cfg['EXPLAIN_MAX'] + 2))
        done = 0
        for i in chosen:
            if done >= budget_turns or not self.can_act() or self.time_left() < self.cfg['WRAPUP_SECONDS'] - 60:
                break
            if i in self.blacklist or i in self.done_exams:
                continue
            entry = self.act('EXAM', banks.EXAM_BY_ID[i][1], phase='exam', qid=i)
            if entry is None:
                continue
            done += 1
            if entry.get('refused'):
                self.blacklist.add(i)
                continue
            entry['system'] = banks.EXAM_BY_ID[i][2]
            self.done_exams.append(i)

    # ------------------------------------------------------------------ 4. 진단 투표
    def diagnose_vote(self):
        from .record import vote_diagnosis
        self.dx, self.dx_detail = vote_diagnosis(self)
        log(f'diagnosis: {self.dx}')

    # ------------------------------------------------------------------ 5. 계획 + 설명
    def make_plan(self):
        from .record import write_plan
        self.plan = write_plan(self)

    def explain(self, quick=False):
        lines = []
        if not quick and self.budget.can_call(self.cfg['CALL_RESERVE']) and self.time_left() > 240:
            lines = self.explanation_lines()
        if not lines:
            lines = fallback_explanation(self.dx_ko(), quick)
        max_lines = 2 if quick else self.cfg['EXPLAIN_MAX'] + 1
        if len(lines) > max_lines:
            lines = lines[:max_lines - 1] + [lines[-1]]
        sent = 0
        last = None
        for line in lines:
            if sent >= max_lines or not self.can_act():
                break
            entry = self.act('SAY', line, phase='explain')
            if entry and not entry.get('refused'):
                self.explained.append(line)
                last = entry
                sent += 1
        # 환자가 마지막에 질문하면 한 번 더 답한다
        if last and not quick and self.can_act() and looks_like_question(last.get('reply', '')):
            answer = self.answer_patient(last['reply']) or '검사 결과를 보고 재진 때 자세히 설명드릴게요.'
            if answer:
                entry = self.act('SAY', answer, phase='explain-answer')
                if entry and not entry.get('refused'):
                    self.explained.append(answer)

    def dx_ko(self) -> str:
        d = self.dx or ''
        return re.sub(r'\s*\(.*?\)\s*$', '', d).strip() or d

    def explanation_lines(self) -> list[str]:
        ice = [e for e in self.ledger if e.get('qid', '').startswith('ice')]
        ice_txt = '\n'.join(f"{e['text']} -> {e['reply']}" for e in ice) or '(없음)'
        p = self.plan or {}
        sys_prompt = DOCTOR_ROLE + ' 진료를 마무리하며 환자에게 쉬운 말로 설명합니다. JSON 객체 하나만 출력하세요.'
        audience = '보호자(아이 부모)' if self.profile.get('pediatric') else '환자'
        user = (f'{self.start_info()}\n\n진료 내용:\n{self.transcript()}\n\n주진단: {self.dx}\n'
                f'추가 검사 계획: {p.get("tests", "")}\n치료: {p.get("treatment", "")}\n'
                f'추적·경고 증상: {p.get("follow_up", "")}\n{audience}의 걱정·기대: {ice_txt}\n\n'
                f'진료를 마치며 {audience}에게 설명할 내용의 "빈칸"만 채우세요. 문장은 프로그램이 만듭니다.\n'
                + EXPLAIN_SLOT_SPEC)
        res = ask_json(self.client, self.budget, sys_prompt, user, effort=self.cfg['EXPLAIN_EFFORT'], max_tokens=5000,
                       tag='explain', want=dict, tries=2, reserve=self.cfg['CALL_RESERVE'],
                       validate=lambda v: bool(str(v.get('dx_plain') or '').strip()))
        slots = clean_slots(res or {})
        lines, too_long = render_explanation(slots)
        if too_long:
            fix = ask_json(self.client, self.budget, DOCTOR_ROLE,
                           '아래 빈칸 값들을 뜻을 유지하며 더 짧고 쉬운 말로 다시 쓰세요. 띄어쓰기는 반드시 지키고(붙여 쓰기 금지), '
                           '명사구 칸은 12자 이내, 문장 칸은 25자 이내. 같은 키로 JSON 하나만 출력.\n'
                           + json.dumps({k: slots.get(k, '') for k in too_long}, ensure_ascii=False),
                           effort='low', max_tokens=1500, tag='explain-shorten', want=dict, tries=1,
                           reserve=self.cfg['CALL_RESERVE'])
            slots.update({k: v for k, v in clean_slots(fix or {}).items() if k in too_long and v})
            lines, _ = render_explanation(slots)
        return lines

    def answer_patient(self, question: str) -> str:
        res = ask(self.client, self.budget, DOCTOR_ROLE,
                  f'주진단: {self.dx}\n계획: {self.plan.get("tests", "")} / {self.plan.get("treatment", "")}\n'
                  f'환자가 마지막에 이렇게 말했습니다: "{question}"\n'
                  '환자에게 할 답 한 문장(쉬운 존댓말, 28자 이내)을 JSON {"answer": "..."} 으로만 출력. '
                  '지킬 수 없는 약속(결과 날짜 등)이나 단정적 안심은 하지 말고, 모르는 것은 "검사 후 재진 때 설명드릴게요"처럼 답할 것. '
                  '위 계획(검사·치료)과 모순되는 말(예: 검사가 필요 없다)은 하지 말 것.',
                  effort='low', max_tokens=1200, tag='answer', want=dict, reserve=self.cfg['CALL_RESERVE'])
        a = nfc((res or {}).get('answer') or '').strip()
        return a if fits(a) else ''


def exam_name(request: str) -> str:
    t = nfc(request).strip()
    for suf in (' 하겠습니다', '하겠습니다', '할게요', ' 할게요'):
        if t.endswith(suf):
            t = t[: -len(suf)].strip()
            break
    return t


def looks_like_question(reply: str) -> bool:
    r = nfc(reply)
    return '?' in r or bool(re.search(r'(궁금|건가요|나요|까요|어떻게|언제|얼마나)', r))


EXPLAIN_SLOT_SPEC = (
    '규칙: 쉬운 우리말, 의학 약어·영어 금지, 맞춤법·띄어쓰기 정확(글자 수를 맞추려고 붙여 쓰지 말 것). 명사구 칸은 조사·마침표 없이 '
    '명사구만. 단정적 안심("걱정 안 해도 돼요") 금지.\n'
    '{"dx_plain": "환자도 아는 표준 병명, 10자 이내 (예: 위염, 갑상선 기능 항진증)",\n'
    ' "cause_plain": "원인 명사구, 12자 이내 (예: 위산 과다)",\n'
    ' "tests": "필요한 검사 1~2개 명사구, 14자 이내 (예: 위내시경과 피검사)",\n'
    ' "treatment": "계획에 적힌 치료 방향 명사구, 14자 이내 (예: 위산 억제 약물). 치료가 검사 뒤 결정이면 \'검사 결과에 맞는 치료\', '
    '약을 끊거나 줄여야 하면 \'약을 천천히 줄이는 치료\'",\n'
    ' "warning": "이 병에서 특히 위험해 바로 다시 와야 할 증상 명사구, 14자 이내 (예: 피를 토함이나 검은 변)",\n'
    ' "lifestyle": "생활 수칙 완결 문장, 25자 이내, 존댓말 (예: 술과 매운 음식은 피하세요.)",\n'
    ' "concern_reply": "환자의 걱정·기대에 직접 답하는 완결 문장, 28자 이내 (예: 암인지는 내시경으로 확인해 볼게요.)"}')


def _batchim(word: str) -> bool | None:
    w = re.sub(r'[^가-힣]', '', word or '')
    if not w:
        return None
    return (ord(w[-1]) - 0xAC00) % 28 != 0


def _rieul(word: str) -> bool:
    w = re.sub(r'[^가-힣]', '', word or '')
    return bool(w) and (ord(w[-1]) - 0xAC00) % 28 == 8


def josa(word: str, pair: str) -> str:
    """pair: '이가', '을를', '으로'"""
    b = _batchim(word)
    if pair == '이가':
        return word + ('이' if b else '가')
    if pair == '을를':
        return word + ('을' if b else '를')
    if pair == '으로':
        return word + ('으로' if b and not _rieul(word) else '로')
    return word


def clean_slots(res: dict) -> dict:
    out = {}
    for k in ('dx_plain', 'cause_plain', 'tests', 'treatment', 'warning'):
        v = nfc(str(res.get(k) or '')).strip()
        v = re.sub(r'[.。!?,]+$', '', v).strip()
        v = re.sub(r'(이|가|을|를|으로|로)$', '', v) if len(v) > 3 and k in ('tests', 'treatment') else v
        out[k] = v
    for k in ('lifestyle', 'concern_reply'):
        v = nfc(str(res.get(k) or '')).strip()
        if re.search(r'(걱정\s*(안|않)|걱정하지\s*마|괜찮을\s*거|문제없)', v):
            v = ''
        out[k] = v
    return out


def render_explanation(slots: dict) -> tuple[list[str], list[str]]:
    """슬롯 → 템플릿 문장. (문장 목록, 30자를 넘기거나 띄어쓰기가 무너진 슬롯 키 목록)"""
    lines, too_long = [], []
    slots = dict(slots)
    for k, v in list(slots.items()):
        if v and re.search(r'[가-힣]{9,}', v):  # 띄어쓰기 없이 붙여 쓴 긴 덩어리
            too_long.append(k)
            slots[k] = ''
    dx, cause = slots.get('dx_plain', ''), slots.get('cause_plain', '')
    if dx:
        one = f"{cause} 때문에 생긴 {josa(dx, '이가')} 의심돼요." if cause else ''
        if one and fits(one):
            lines.append(one)
        else:
            first = f"{josa(dx, '이가')} 의심돼요."
            if fits(first):
                lines.append(first)
            else:
                too_long.append('dx_plain')
            if cause:
                second = f'{cause} 때문으로 보여요.'
                if fits(second):
                    lines.append(second)
                else:
                    too_long.append('cause_plain')
    for key, tpl in (('tests', "{x} 확인할게요."), ('treatment', "{x} 치료할 수 있어요."),
                     ('warning', "{x} 있으면 바로 오세요.")):
        v = slots.get(key, '')
        if not v:
            continue
        x = josa(v, '이가') if key == 'warning' else josa(v, '으로')
        s = tpl.format(x=x)
        if fits(s):
            lines.append(s)
        else:
            too_long.append(key)
    for key in ('lifestyle', 'concern_reply'):
        v = slots.get(key, '')
        if not v:
            continue
        if fits(v):
            lines.append(v)
        else:
            too_long.append(key)
    if lines:
        lines.append('더 궁금한 점 있으세요?')
    return lines, too_long


def fallback_explanation(dx_ko: str, quick: bool) -> list[str]:
    first = f'{dx_ko} 가능성이 높아 보여요.' if dx_ko else ''
    if not fits(first):
        first = '말씀과 진찰로 원인이 짐작돼요.'
    lines = [first, '정확한 확인을 위해 검사가 필요해요.', '검사 결과를 보고 치료를 정할게요.',
             '증상이 심해지면 바로 다시 오세요.', '무리하지 마시고 충분히 쉬세요.', '더 궁금한 점 있으세요?']
    if quick:
        return [first, '검사 후 치료를 정하고, 심해지면 바로 오세요.' if fits('검사 후 치료를 정하고, 심해지면 바로 오세요.')
                else '심해지면 바로 다시 오세요.']
    return lines
