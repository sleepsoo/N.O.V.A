"""N.O.V.A. 2026 예선 Doctor Agent.

흐름: 시작 정보 구조화(LLM low) → 공감 1턴 → 문진(규칙 기반 질문 은행 + LLM 적응형 2라운드 + ICE)
     → 진찰(표준 명칭 진찰 은행에서 LLM이 id 선택, 자유 문구 없음) → 진단 다수결(LLM high ×3)
     → 계획(P) → 환자 설명 SAY 5~6턴 → S(LLM)·O(프로그램)·A(LLM)·P 기록 → DIAGNOSE.
어떤 예외가 나도 finally에서 기록을 만들어 client.diagnose를 시도한다.
표준 라이브러리만 사용하며 파일을 쓰지 않는다. 로그는 stderr로만 남긴다.
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nova_sdk import run_agent  # noqa: E402

from agent import record as rec  # noqa: E402
from agent.encounter import Encounter  # noqa: E402
from agent.util import error_summary, log, log_error  # noqa: E402

# ------------------------------------------------------------------ 설정 (환경변수 NOVA_AGENT_<이름>으로 덮어쓰기 가능)
DEFAULTS = {
    # 턴 예산
    'INTERVIEW_MAX': 30,       # 문진 SAY 최대(공감·설명 제외)
    'HPI_MAX': 3,              # 핵심 현병력 질문
    'BUNDLE_MAX': 6,           # 주호소 카테고리 묶음 질문(첫 카테고리 4개 우선)
    'ADAPTIVE1_MAX': 2,        # 적응형 1라운드
    'ADAPTIVE2_MAX': 3,        # 적응형 2라운드(ROS 뒤, 최소 2개 보장)
    'ROS_MIN': 3,              # 과거력 뒤 핵심 ROS 최소 보장 수
    'ROS_MAX': 6,              # 핵심 ROS 최대
    'EXAM_SELECT': 5,          # LLM이 고르는 진찰 수(활력징후·외관·심음·폐 청진 제외)
    'EXAM_MAX': 9,             # 진찰 턴 최대
    'EXPLAIN_MAX': 6,          # 마무리 설명 SAY(+ "더 궁금한 점 있으세요?" 1턴, 환자 질문 답 1턴)
    'EXPLAIN_EFFORT': 'medium',
    # 시간·호출 안전 마진
    'WRAPUP_SECONDS': 540,     # 남은 시간이 이보다 적으면 문진·진찰을 멈추고 마무리
    'QUICK_EXPLAIN_SECONDS': 360,  # 이보다 적으면 설명 2턴(고정 문구)만
    'RECORD_MIN_SECONDS': 100,  # 이보다 적으면 LLM 없이 폴백 기록 제출
    'CALL_RESERVE': 15,        # 기록 작성용으로 남겨 둘 Doctor 호출 수
    # Doctor 모델 설정
    # 진단 다수결 표(앞의 두 표가 같으면 세 번째 생략). high는 부하 시 240초 넘게 걸리거나 길이 초과가 나서 medium만 사용
    'DX_EFFORTS': 'medium,medium,medium',
    'DX_MAX_TOKENS': 8000,
    'DX_TEMPERATURE': 0.7,
    'PLAN_EFFORT': 'medium',   # high는 부하 시 180초 초과(PROVIDER_UNAVAILABLE) 위험이 커서 medium
    'PLAN_MAX_TOKENS': 6000,
    'S_EFFORT': 'medium',
    'JUDGE_EFFORT': 'medium',  # 문답 판정(S칸 체크리스트)
    'S_MAX_TOKENS': 6000,
    'A_EFFORT': 'medium',
    'A_MAX_TOKENS': 6000,
}

LAST_RUN = {}  # 로컬 도구(tools/)가 실행 뒤 통계를 읽는 용도. 제출 환경에서는 쓰지 않음.


def load_config():
    cfg = dict(DEFAULTS)
    for key, default in DEFAULTS.items():
        raw = os.environ.get('NOVA_AGENT_' + key)
        if raw is None or raw == '':
            continue
        try:
            if isinstance(default, bool):
                cfg[key] = raw.lower() in ('1', 'true', 'yes')
            elif isinstance(default, int):
                cfg[key] = int(raw)
            elif isinstance(default, float):
                cfg[key] = float(raw)
            else:
                cfg[key] = raw
        except ValueError:
            pass
    return cfg


def prepare():
    guide = os.environ.get('NOVA_GUIDELINES_DIR')
    log(f'prepare: guidelines dir {"present" if guide and os.path.isdir(guide) else "absent"} (이번 버전은 미사용)')
    return {'config': load_config()}


PHASE_TIMES = {}


def _phase(name, fn, *args):
    t0 = time.time()
    try:
        return fn(*args)
    except Exception as exc:  # 단계 실패는 다음 단계로 넘어간다
        log_error(f'phase {name} failed: {type(exc).__name__}: {exc}')
        return None
    finally:
        PHASE_TIMES[name] = round(time.time() - t0, 1)


def consult(client, state):
    cfg = (state or {}).get('config') if isinstance(state, dict) else None
    cfg = cfg or load_config()
    started = time.time()
    enc = None
    result = None
    try:
        enc = Encounter(client, cfg)
        _phase('structure', enc.structure)
        if not enc.profile:
            enc.profile = {'age': None, 'sex': '', 'pediatric': False, 'cc': enc.opening[:40], 'categories': [],
                           'answered': [], 'empathy': '많이 걱정되셨겠어요.'}
        if enc.phase_time_ok():
            _phase('interview', enc.interview)
        if enc.phase_time_ok() or enc.time_left() > cfg['QUICK_EXPLAIN_SECONDS'] + 60:
            _phase('examine', enc.examine)
        if enc.time_left() > cfg['RECORD_MIN_SECONDS'] + 120:
            _phase('diagnose_vote', enc.diagnose_vote)
        if enc.time_left() > cfg['QUICK_EXPLAIN_SECONDS']:
            _phase('plan', enc.make_plan)
        _phase('explain', enc.explain, enc.time_left() < cfg['QUICK_EXPLAIN_SECONDS'])
    except Exception as exc:
        log_error(f'consult failed: {type(exc).__name__}: {exc}')
    finally:
        result = finish(client, enc, cfg)
        if enc is not None:
            LAST_RUN.clear()
            LAST_RUN.update({'counts': enc.counts, 'budget': enc.budget.stats(), 'profile': enc.profile,
                             'diagnosis': enc.dx, 'dx_detail': enc.dx_detail, 'differentials': enc.differentials,
                             'turn': enc.turn, 'call_log': enc.budget.call_log, 'ledger': enc.ledger,
                             'seconds': round(time.time() - started, 1), 'result': result,
                             'note': getattr(enc, 'final_note', None), 'plan': enc.plan, 'explained': enc.explained,
                             'findings': getattr(enc, 'findings', None), 'phase_times': dict(PHASE_TIMES)})
            log(f'summary: turns={enc.turn} counts={enc.counts} budget={enc.budget.stats()} dx={enc.dx}')
        errs = error_summary()
        if errs:
            log('error summary: ' + ' | '.join(errs))
    return result


def finish(client, enc, cfg):
    """기록 작성·제출. 무슨 일이 있어도 diagnose를 시도한다."""
    from nova_sdk import empty_record
    if enc is None:
        try:
            enc = Encounter(client, cfg)
        except Exception as exc:
            log_error(f'cannot open session for record: {exc}')
            note = empty_record()
            note['S']['hpi'] = '세션 정보를 읽지 못함'
            try:
                return client.diagnose(note=note, diagnosis='진단 미정')
            except Exception as exc2:
                log_error(f'diagnose failed: {exc2}')
                return None
    note = None
    diagnosis = enc.dx or ''
    try:
        llm_ok = enc.time_left() > cfg['RECORD_MIN_SECONDS']
        if not diagnosis and llm_ok:
            _phase('diagnose_vote_late', enc.diagnose_vote)
            diagnosis = enc.dx or ''
        s = {}
        if llm_ok:
            s = _phase('S', rec.write_subjective, enc) or {}
            if s and enc.time_left() > cfg['RECORD_MIN_SECONDS']:
                s = _phase('S-verify', rec.verify_numbers, enc, s) or s
        o_exam = rec.write_objective(enc)
        a = {}
        if enc.time_left() > cfg['RECORD_MIN_SECONDS']:
            a = _phase('A', rec.write_assessment, enc, s, o_exam) or {}
        plan = enc.plan
        if not plan and enc.time_left() > cfg['RECORD_MIN_SECONDS']:
            plan = _phase('plan_late', rec.write_plan, enc) or {}
        note = rec.build_note(enc, s, o_exam, a, plan)
    except Exception as exc:
        log_error(f'record build failed: {type(exc).__name__}: {exc}')
    if note is None:
        try:
            note = rec.build_note(enc, {}, rec.write_objective(enc), {}, {})
        except Exception as exc:
            log_error(f'fallback record failed: {exc}')
            note = empty_record()
            note['S']['hpi'] = enc.opening or '기록 없음'
            note['O']['exam'] = enc.transcript()
    if enc.budget.ok_calls == 0 and enc.time_left() > 30:
        # 증례마다 Doctor 모델을 최소 1회 호출해야 한다(미호출 시 0점)
        from agent.llm import ask
        ask(client, enc.budget, '', '진단명 하나만 답하세요: ' + enc.opening, effort='low', max_tokens=600,
            json_expected=False, tag='min-call', max_wait=60)
    enc.final_note = note
    if not diagnosis:  # 투표 실패: 적응형 문진의 감별진단 1순위, 없으면 주호소 기반
        diagnosis = (enc.differentials[0] if enc.differentials else '') or \
            (f"{enc.profile.get('cc')} (원인 감별 필요)" if enc.profile.get('cc') else '진단 미정')
    return rec.submit(enc, note, diagnosis)


if __name__ == '__main__':
    run_agent(prepare, consult)
