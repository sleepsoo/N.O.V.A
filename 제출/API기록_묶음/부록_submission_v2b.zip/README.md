# 부록_submission_v2b

v2 lean40 변형. 점수 보고 없음(제출 여부 미확인).

- 제출 파일: `submission_v2b.zip`
- 사용자 보고 점수: 없음

- 턴수(사용자 보고): 보고 없음

## 서버(API) 샘플 세션 기록 (개발 키로 실행, 채점 파일은 세션 밖 자가채점)

| 증례 | 폴더 | 턴 | 진단 적중 | 자가채점 파일 |
|---|---|---|---|---|
| C01 | C01-20261013-102016-v2-r7-lean40 | 40 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |
| C03 | C03-20261013-102020-v2-r7-lean40 | 40 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |
| C10 | C10-20261013-102029-v2-r7-lean40 | 39 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |

파일: transcript.md(대화), session.json(서버 세션 원본), record.json/md(제출 기록), ledger.json(Doctor 호출), summary.json(요약), grade_*.json(자가채점: luna/sol, _official=공식형 루브릭).
