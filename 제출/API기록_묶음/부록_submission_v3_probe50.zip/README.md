# 부록_submission_v3_probe50

v3 probe50(50턴). 점수 보고 없음(제출 여부 미확인).

- 제출 파일: `submission_v3_probe50.zip`
- 사용자 보고 점수: 없음

- 턴수(사용자 보고): 보고 없음

## 서버(API) 샘플 세션 기록 (개발 키로 실행, 채점 파일은 세션 밖 자가채점)

| 증례 | 폴더 | 턴 | 진단 적중 | 자가채점 파일 |
|---|---|---|---|---|
| C01 | C01-20261013-114136-v3-final | 49 | True | grade_gpt-6.1-sol.json |
| C03 | C03-20261013-114020-v3-final | 49 | True | grade_gpt-6.1-sol.json |
| C10 | C10-20261013-114139-v3-final | 49 | True | grade_gpt-6.1-sol.json |

파일: transcript.md(대화), session.json(서버 세션 원본), record.json/md(제출 기록), ledger.json(Doctor 호출), summary.json(요약), grade_*.json(자가채점: luna/sol, _official=공식형 루브릭).
