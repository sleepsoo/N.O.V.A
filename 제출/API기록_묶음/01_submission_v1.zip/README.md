# 01_submission_v1

통합 v1 (Doctor gpt-oss-20b 시기 작성, 10-13부터 luna). 10-12 r3 세션 직후 패키징.

- 제출 파일: `submission_v1.zip`
- 사용자 보고 점수 (샘플 검증): **75.3**

| 정보수집 | 진단추론 | 검사·추적 | 안전 | 의사소통 | 효율 | 총점 |
|---|---|---|---|---|---|---|
| 12.83/25 | 15.00/15 | 8.61/10 | 15.00/15 | 6.94/15 | 16.88/20 | 75.3 |

- 턴수(사용자 보고): 보고 없음

## 서버(API) 샘플 세션 기록 (개발 키로 실행, 채점 파일은 세션 밖 자가채점)

| 증례 | 폴더 | 턴 | 진단 적중 | 자가채점 파일 |
|---|---|---|---|---|
| C01 | C01-20261012-192048-r3 | 48 | False | grade_gpt-6-luna.json |
| C03 | C03-20261012-190556-r3 | 48 | False | grade_gpt-6-luna.json |
| C10 | C10-20261012-193316-r3 | 46 | True | grade_gpt-6-luna.json |
| C10 | C10-20261013-081049-r4-luna | 48 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |

파일: transcript.md(대화), session.json(서버 세션 원본), record.json/md(제출 기록), ledger.json(Doctor 호출), summary.json(요약), grade_*.json(자가채점: luna/sol, _official=공식형 루브릭).
