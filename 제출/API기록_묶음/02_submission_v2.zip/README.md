# 02_submission_v2

v2 (bal44, 체크리스트+luna 계획, 사실표 S, 템플릿 P). v2-final 세션 직후 패키징.

- 제출 파일: `submission_v2.zip`
- 사용자 보고 점수 (샘플 검증): **77.3**

| 정보수집 | 진단추론 | 검사·추적 | 안전 | 의사소통 | 효율 | 총점 |
|---|---|---|---|---|---|---|
| 15.27/25 | 15.00/15 | 8.69/10 | 10.00/15 | 8.94/15 | 19.42/20 | 77.3 |

- 턴수(사용자 보고): 보고 없음

## 서버(API) 샘플 세션 기록 (개발 키로 실행, 채점 파일은 세션 밖 자가채점)

| 증례 | 폴더 | 턴 | 진단 적중 | 자가채점 파일 |
|---|---|---|---|---|
| C01 | C01-20261013-100741-v2-final | 44 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |
| C03 | C03-20261013-100703-v2-final | 43 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |
| C10 | C10-20261013-100740-v2-final | 43 | True | grade_gpt-6-luna.json, grade_gpt-6.1-sol.json, grade_gpt-6.1-sol_official.json |

파일: transcript.md(대화), session.json(서버 세션 원본), record.json/md(제출 기록), ledger.json(Doctor 호출), summary.json(요약), grade_*.json(자가채점: luna/sol, _official=공식형 루브릭).
