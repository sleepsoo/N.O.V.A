# 04_submission_v3

v3 GEN(일반화 우선, 34~40턴). v3-gen 세션 직후 패키징.

- 제출 파일: `submission_v3.zip`
- 사용자 보고 점수 (샘플 검증): **78.9**

| 정보수집 | 진단추론 | 검사·추적 | 안전 | 의사소통 | 효율 | 총점 |
|---|---|---|---|---|---|---|
| 12.71/25 | 15.00/15 | 9.33/10 | 15.00/15 | 7.06/15 | 19.84/20 | 78.9 |

- 턴수(사용자 보고): C01 40턴·175초 / C10 37턴·190초 / C03 39턴·184초

## 서버(API) 샘플 세션 기록 (개발 키로 실행, 채점 파일은 세션 밖 자가채점)

| 증례 | 폴더 | 턴 | 진단 적중 | 자가채점 파일 |
|---|---|---|---|---|
| C01 | C01-20261013-124131-v3-gen | 39 | True | grade_gpt-6.1-sol_official.json |
| C03 | C03-20261013-124024-v3-gen | 39 | True | grade_gpt-6.1-sol_official.json |
| C10 | C10-20261013-124054-v3-gen | 39 | True | grade_gpt-6.1-sol_official.json |

파일: transcript.md(대화), session.json(서버 세션 원본), record.json/md(제출 기록), ledger.json(Doctor 호출), summary.json(요약), grade_*.json(자가채점: luna/sol, _official=공식형 루브릭).
